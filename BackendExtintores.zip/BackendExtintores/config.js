const API_VERSION = "v1";
const DB_URL = `mongodb+srv://extintores:19950323@cluster0.2mwco.mongodb.net/extintordb?retryWrites=true&w=majority`;
const IP_SERVER = "192.168.20.46" || "0.0.0.0";
const PORT_DB = 4000;

module.exports = {
  API_VERSION,
  DB_URL,
  IP_SERVER,
  PORT_DB,
};
